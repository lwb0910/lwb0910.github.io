import random
num=[]
name=[]
print("欢迎使用教学助手!")
first=input("您是否为首次使用该系统? (Y/N) ")
if first=='Y':
    password=input("您是首次使用该系统, 为了数据安全, 请您设置登录密码, 并牢记: ")
    with open("user.data", "w") as file: file.write(password)
    print("设置成功!")
password=input("请输入登录密码: ")
with open("user.data", "r") as file:
    if password==file.readlines()[0]:
        print("登录成功!")
        while True:
            op=input("1: 新建人名单\n2: 作业统计\n3: 成绩记录\n4: 课上随机点名\n请输入操作号: ")
            if op=='1':
                print("请您按照提示分别输入学号、姓名, 当您想要结束输入时, 请输入\"-1\"")
                cc=0
                while True:
                    print("请输入第", cc+1, "位同学的学号: ", sep='', end='')
                    numT=input()
                    if numT=="-1": break
                    num.append(numT)
                    print("请输入第", cc+1, "位同学的姓名: ", sep='', end='')
                    name.append(input())
                    cc+=1
                with open("student.data", "w") as file:
                    file.write(str(cc)+'\n')
                    for i in range(cc): file.write(num[i]+'\n')
                    for i in range(cc): file.write(name[i]+'\n')
                print("\n人名单保存成功!\n")
            elif op=='2':
                with open("student.data", "r") as file:
                    t=file.readlines()
                cc=int(t[0])
                num=[]
                name=[]
                for i in range(cc): num.append(t[i+1])
                for i in range(cc): name.append(t[cc+i+1])
                numT=list(num)
                nameT=list(name)
                print("请您输入提交作业的同学的学号, 输入完成后输入\"-1\"")
                while True:
                    tmp=input("请输入学生学号: ")
                    if tmp=="-1": break
                    for i in range(cc):
                        if numT[i]==tmp+'\n':
                            del numT[i]
                            break
                print("\n没交作业的有:")
                for i in numT:
                    for j in range(len(i)):
                        if i[j]!='\n': print(i[j], end='')
                    for j in range(cc):
                        if num[j]==i:
                            print(name[j], end='')
                            break
                print()
            elif op=='3':
                with open("student.data", "r") as file:
                    t=file.readlines()
                cc=int(t[0])
                num=[]
                name=[]
                for i in range(cc): num.append(t[i+1])
                for i in range(cc): name.append(t[cc+i+1])
                project=input("成绩将与该程序保存在同一文件夹中, 请为本次成绩记录设置名称: ")
                with open(project+".txt", "w") as file:
                    print("请输入学号, 输入完成后输入\"-1\"")
                    while True:
                        tmp=input("请输入学生学号: ")
                        if tmp=="-1": break
                        file.write(tmp)
                        score=input("请输入学生成绩: ")
                        for i in range(cc):
                            if num[i]==tmp+'\n':
                                for j in name[i]:
                                    if j!='\n': file.write(j)
                                break
                        file.write(' '+score+'\n')
                    print("\n文件保存成功!\n")
            elif op=='4':
                with open("student.data", "r") as file:
                    t=file.readlines()
                cc=int(t[0])
                num=[]
                name=[]
                for i in range(cc): num.append(t[i+1])
                for i in range(cc): name.append(t[cc+i+1])
                n=random.randint(0, cc-1)
                print("\n随机结果为: ", end='')
                for i in num[n]:
                    if i!='\n': print(i, end='')
                print(name[n])
            else: print("\n输入错误!\n")